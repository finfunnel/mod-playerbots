/*
 * This file is part of the mod-playerbots module for AzerothCore. See AUTHORS file for Copyright
 * information; released under GNU GPL v2 license, redistribute/modify under version 2 of the License,
 * or (at your option) any later version.
 */

#ifndef PLAYERBOTS_AQ40TRIGGERS_H
#define PLAYERBOTS_AQ40TRIGGERS_H

#include "EncounterHelpers.h"
#include "Trigger.h"

/*
 * Temple of Ahn'Qiraj (AQ40, map 531).
 * The Prophet Skeram (NPC 15263). IDs verified against boss_skeram.cpp + temple_of_ahnqiraj.h:
 * - True Fulfillment 785: mind control on the player farthest from the boss (MinDistance
 *   target); the controlled player must be polymorphed by a mage (guide).
 * - Arcane Explosion 26192: point-blank AoE spammed by boss AND images - melee unfriendly,
 *   nothing to dodge for ranged, no bot-side handling needed beyond default spread.
 * - Earth Shock 26194: spammed on random targets while NO tank holds the boss - all tanks
 *   must rush to pick up boss/images after every split/teleport.
 * - Summon Images 747 at 75/50/25%: two images share the boss entry 15263 with 10-50% of
 *   his health (JustSummoned). Guide: kill images first (they deal heavy AoE), tanks pick
 *   each copy up.
 * - Blink/teleports (3 platforms): threat resets on teleport - DPS must hold until tanks
 *   re-establish threat (handled by making image/boss pickup tank-only and letting the
 *   default engine's threat checks gate DPS).
 */
enum TempleOfAhnQirajIDs
{
    NPC_THE_PROPHET_SKERAM               = 15263, // images share this entry (summoned by 747)

    SPELL_TRUE_FULFILLMENT               = 785,   // mind control; counter = polymorph
    SPELL_ARCANE_EXPLOSION_AQ40          = 26192,
    SPELL_EARTH_SHOCK_AQ40               = 26194,

    // ---- Battleguard Sartura (boss_sartura.cpp + temple_of_ahnqiraj.h) ----
    NPC_SARTURA                          = 15516,
    NPC_SARTURA_ROYAL_GUARD              = 15984,
    SPELL_WHIRLWIND_SARTURA              = 26083, // boss whirlwind, 15s, random hops + threat wipes
    SPELL_GUARD_WHIRLWIND                = 26038, // royal guard whirlwind, 8s
    SARTURA_WHIRLWIND_ESCAPE_RANGE       = 12,   // melee run out during whirlwind
    SARTURA_SEARCH_RANGE                 = 80,   // boss room radius

    // ---- Bug Trio: Lord Kri / Princess Yauj / Vem (boss_bug_trio.cpp) ----
    NPC_KRI                              = 15511,
    NPC_YAUJ                             = 15543,
    NPC_VEM                              = 15544,
    SPELL_YAUJ_FEAR                      = 26580, // AoE fear every ~20s + threat reset
    SPELL_KRI_POISON_CLOUD               = 26590, // spawned on Kri's corpse, ~2000 nature dps
    SPELL_KRI_TOXIC_VOLLEY               = 25812, // nature damage + DoT on the raid
    BUG_TRIO_SEARCH_RANGE                = 80,
    POISON_CLOUD_ESCAPE_RANGE            = 12,   // run this far from a poison cloud

    // ---- Fankriss the Unyielding (boss_fankriss.cpp) ----
    NPC_FANKRISS                         = 15510,
    NPC_SPAWN_OF_FANKRISS                = 15630, // "Spawn of Fankriss" - the sandworms
    NPC_VEKNISS_HATCHLING                = 15962, // endless beetle adds (respawn on death)
    SPELL_MORTAL_WOUND_FANKRISS          = 25646, // frontal stacking healing debuff
    FANKRISS_MORTAL_WOUND_SWAP_STACKS    = 5,     // tank swap threshold
    FANKRISS_SEARCH_RANGE                = 80,

    // ---- Viscidus (boss_viscidus.cpp) ----
    NPC_VISCIDUS                         = 15299,
    NPC_GLOB_OF_VISCIDUS                 = 15667, // split globs: each kill = boss -5% HP
    NPC_TOXIC_SLIME                      = 15925, // stationary poison-cloud slime
    SPELL_VISCIDUS_SLOWED                = 26034,
    SPELL_VISCIDUS_SLOWED_MORE           = 26036,
    SPELL_VISCIDUS_FREEZE                = 25937, // fully frozen: melee it to shatter
    SPELL_TOXIN_CLOUD                    = 26575, // aura cast by the Toxic Slime
    VISCIDUS_SEARCH_RANGE                = 80,
    TOXIN_ESCAPE_RANGE                   = 12,    // run this far from a slime cloud

    // ---- Princess Huhuran (boss_huhuran.cpp) ----
    NPC_HUHURAN                          = 15509,
    SPELL_HUHURAN_BERSERK                = 26068, // 30% enrage: Poison Bolt AoE on nearest 15
    SPELL_HUHURAN_FRENZY                 = 26051, // periodic soft enrage (tranq shot)
    SPELL_HUHURAN_NOXIOUS_POISON         = 26053, // stacking poison pool on random targets
    HUHURAN_SEARCH_RANGE                 = 80,

    // ---- Twin Emperors (boss_twinemperors.cpp) ----
    NPC_VEKLOR                           = 15276, // caster emperor (magic-immune)
    NPC_VEKNILASH                        = 15275, // melee emperor (physical-immune)
    SPELL_TWINS_UNBALANCING_STRIKE             = 26613, // -100 defense on the tank, tank swap
    SPELL_ARCANE_BURST_TWINS             = 568,   // caster AoE burst when melee gets close
    TWIN_EMPERORS_SEARCH_RANGE           = 80,
    TWIN_EMPERORS_SEPARATION             = 60,    // heal-brother range is 60yd

    // ---- Ouro (boss_ouro.cpp) ----
    NPC_OURO                             = 15517, // sand worm boss
    NPC_DIRT_MOUND                       = 15712, // submerge-phase mounds chasing players
    NPC_OURO_SCARAB                      = 15718, // adds spawned on re-emerge / berserk
    SPELL_OURO_SAND_BLAST                = 26102, // 45yd frontal breath on max-threat, threat wipe
    SPELL_OURO_SWEEP                     = 26103, // tail knockback on players behind the boss
    SPELL_OURO_SUBMERGE_VISUAL           = 26063, // boss dives / is untargetable while submerged
    OURO_SEARCH_RANGE                    = 80,
    OURO_MOUND_ESCAPE_RANGE              = 12,    // run this far from a chasing dirt mound

    // ---- C'Thun (boss_cthun.cpp) ----
    NPC_EYE_OF_CTHUN                     = 15589, // P1 eye: green beam / Dark Glare
    NPC_BODY_OF_CTHUN                    = 15809, // P2 body: eat players, weakens via flesh tentacles
    NPC_EYE_TENTACLE                     = 15726, // small eye tentacles (P1+P2)
    NPC_CLAW_TENTACLE                    = 15725, // small claw tentacles (P1+P2)
    NPC_GIANT_CLAW_TENTACLE              = 15728, // P2 giant claw: heavy melee, tank it
    NPC_GIANT_EYE_TENTACLE               = 15334, // P2 giant eye: chain-casts, interrupt it
    NPC_FLESH_TENTACLE                   = 15802, // stomach flesh tentacles: 2 dead = weaken
    SPELL_DARK_GLARE                     = 26029, // eye red -> 35s sweeping red beam
    SPELL_RED_COLORATION                 = 22518, // eye turns red right before Dark Glare
    SPELL_DIGESTIVE_ACID                 = 26476, // stacking debuff inside the stomach
    CTHUN_SEARCH_RANGE                   = 80,
    CTHUN_GLARE_STRAFE_RANGE             = 10,    // sidestep chunk while dodging Dark Glare
    CTHUN_STOMACH_Z                      = 0      // z <= this = swallowed (outside z > 0, stomach z = -70)
};

// Stomach depth check uses a real Z compare, so keep it as a float constant outside the enum.
inline constexpr float CTHUN_STOMACH_Z_F = 0.0f;

// IDs kept for Skeram-only lookups (shared boss-room radius).
enum SkeramIDs
{
    AQ40_MAP_ID                          = 531,  // Temple of Ahn'Qiraj
    SKERAM_SEARCH_RANGE                  = 80    // boss room radius
};

// Trigger base: only active while an encounter is in progress in the Temple of Ahn'Qiraj
class AhnQirajEncounterTrigger : public Trigger
{
public:
    AhnQirajEncounterTrigger(PlayerbotAI* ai, std::string const name, int32 checkInterval = 1)
        : Trigger(ai, name, checkInterval) {}

    bool IsActive() final
    {
        return EncounterHelpers::IsEncounterInProgress(bot, AQ40_MAP_ID) && IsActiveInEncounter();
    }

protected:
    virtual bool IsActiveInEncounter() = 0;
};

// ---- The Prophet Skeram ----

// A group member is mind controlled by True Fulfillment (785): mages polymorph them.
// Images and the boss all share entry 15263, so HasAura on a player means MC regardless.
class SkeramMemberMindControlledTrigger : public AhnQirajEncounterTrigger
{
public:
    SkeramMemberMindControlledTrigger(PlayerbotAI* ai)
        : AhnQirajEncounterTrigger(ai, "skeram member mind controlled") {}
    bool IsActiveInEncounter() override;
};

// A Skeram image (summoned copy, entry 15263) exists and is attackable: everyone switches
// to it - images deal heavy AoE and must die first (guide).
class SkeramImageUpTrigger : public AhnQirajEncounterTrigger
{
public:
    SkeramImageUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "skeram image up", 2) {}
    bool IsActiveInEncounter() override;
};

// The boss (or an image) has no living tank on it (post-split / post-teleport): a free tank
// must pick it up at once or it spams Earth Shock (26194) on the raid.
class SkeramUntankedTrigger : public AhnQirajEncounterTrigger
{
public:
    SkeramUntankedTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "skeram untanked") {}
    bool IsActiveInEncounter() override;
};

// ---- Battleguard Sartura ----

// Sartura or a Royal Guard is whirlwinding (26083 / 26038): melee must run out or get
// shredded; threat is wiped constantly so anyone may be the target (guide: 吃控的BOSS,
// 旋风斩立刻清除仇恨，近战停手躲旋风).
class SarturaWhirlwindActiveTrigger : public AhnQirajEncounterTrigger
{
public:
    SarturaWhirlwindActiveTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "sartura whirlwind active", 2) {}
    bool IsActiveInEncounter() override;
};

// A living Royal Guard (15984) is present: kill the three guards first, then the boss
// (guide: 优先击杀三个卫兵，然后杀boss).
class SarturaRoyalGuardUpTrigger : public AhnQirajEncounterTrigger
{
public:
    SarturaRoyalGuardUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "sartura royal guard up", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- Bug Trio (Lord Kri / Princess Yauj / Vem) ----

// Princess Yauj is engaged and about to AoE fear: priests Fear Ward the current tank,
// shamans drop a Tremor Totem (guide: 萨满插好图腾，牧师上好防恐).
class BugTrioFearPrepTrigger : public AhnQirajEncounterTrigger
{
public:
    BugTrioFearPrepTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "bug trio fear prep", 2) {}
    bool IsActiveInEncounter() override;
};

// Kri died and left a poison cloud (26590, ~2000 nature dps): everyone nearby runs out
// (guide: 克里死后尸体周围产生毒云，务必远离).
class BugTrioPoisonCloudTrigger : public AhnQirajEncounterTrigger
{
public:
    BugTrioPoisonCloudTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "bug trio poison cloud", 2) {}
    bool IsActiveInEncounter() override;
};

// Kill-order targets: Vem while Yauj lives, then Kri (guide: 先杀亚尔基公主，再集火维姆，
// 最后杀克里). Everyone follows the order so the raid burns one bug at a time.
class BugTrioKillOrderTargetTrigger : public AhnQirajEncounterTrigger
{
public:
    BugTrioKillOrderTargetTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "bug trio kill order target", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- Fankriss the Unyielding ----

// The current tank's Mortal Wound (25646) stack is at the swap threshold: another tank
// taunts Fankriss off (guide: 致命伤口叠加降低治疗效果，坦克注意换坦).
class FankrissMortalWoundStacksTrigger : public AhnQirajEncounterTrigger
{
public:
    FankrissMortalWoundStacksTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "fankriss mortal wound stacks", 2) {}
    bool IsActiveInEncounter() override;
};

// A sandworm (Spawn of Fankriss, 15630) is alive: tanks pick them up, everyone kills
// them first - they hit extremely hard (guide: 沙虫伤害极高，坦克玩家拉好，优先击杀).
class FankrissSpawnUpTrigger : public AhnQirajEncounterTrigger
{
public:
    FankrissSpawnUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "fankriss spawn up", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- Viscidus ----

// Viscidus is NOT fully frozen (25937) and not yet split: mages spam frost damage to
// stack the freeze counter (guide: 法师直接搓一级寒冰箭冻住boss).
class ViscidusNeedsFrostTrigger : public AhnQirajEncounterTrigger
{
public:
    ViscidusNeedsFrostTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "viscidus needs frost", 2) {}
    bool IsActiveInEncounter() override;
};

// Viscidus is fully frozen (25937): everyone melee attacks it with fast weapons to
// shatter it into globs (guide: 冻结后全体换快速武器敲boss).
class ViscidusFrozenTrigger : public AhnQirajEncounterTrigger
{
public:
    ViscidusFrozenTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "viscidus frozen", 2) {}
    bool IsActiveInEncounter() override;
};

// Split globs (15667) are up: everyone attacks them before they rejoin the boss at the
// room center - each glob killed removes 5% boss HP (guide: 打掉尽可能多的分身).
class ViscidusGlobUpTrigger : public AhnQirajEncounterTrigger
{
public:
    ViscidusGlobUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "viscidus glob up", 2) {}
    bool IsActiveInEncounter() override;
};

// A Toxic Slime (15925) cloud is within escape distance: run out of the poison
// (guide: 场内会产生毒云，玩家注意躲开).
class ViscidusToxinNearTrigger : public AhnQirajEncounterTrigger
{
public:
    ViscidusToxinNearTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "viscidus toxin near", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- Princess Huhuran ----

// Huhuran is berserk (26068, 30% HP): poison-bolt AoE hits the 15 players nearest to
// her - the soakers must be stacked on the boss, everyone else keeps burning
// (guide: 30%后向最靠近的15个目标释放毒镖AOE，自然抗沙包贴身).
class HuhuranBerserkTrigger : public AhnQirajEncounterTrigger
{
public:
    HuhuranBerserkTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "huhuran berserk", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- Twin Emperors ----

// Veklor (caster, magic-immune) has no caster tank on him (post-teleport or missing
// warlock tank): a spell-casting tank (warlock preferred) must grab him or he free-casts
// (guide: 魔皇需要法系职业抗住，传送后坦克立刻拉好).
class TwinEmpVeklorUntankedTrigger : public AhnQirajEncounterTrigger
{
public:
    TwinEmpVeklorUntankedTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "twin emp veklor untanked", 2) {}
    bool IsActiveInEncounter() override;
};

// Veknilash (melee, physical-immune) current victim's Unbalancing Strike (26613,
// -100 defense) demands a tank swap (guide: 重压打击减100防御，战士换坦避免被打死).
class TwinEmpTankSwapTrigger : public AhnQirajEncounterTrigger
{
public:
    TwinEmpTankSwapTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "twin emp tank swap", 2) {}
    bool IsActiveInEncounter() override;
};

// Melee bot's current target is Veklor: he is immune to physical damage AND AoE-bursts
// (568) anyone in melee range - melee must switch off him entirely (guide: 剑皇魔免，
// 魔皇物免，注意输出伤害类型).
class TwinEmpWrongDamageTypeTrigger : public AhnQirajEncounterTrigger
{
public:
    TwinEmpWrongDamageTypeTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "twin emp wrong damage type", 2) {}
    bool IsActiveInEncounter() override;
};

// Veklor and Veknilash are within 60yd of each other: they spam Heal Brother (7393) for
// 30000 every 3.6s - the tanks must drag their assigned twin apart immediately
// (guide: 保持双子皇帝之间距离).
class TwinEmpTooCloseTrigger : public AhnQirajEncounterTrigger
{
public:
    TwinEmpTooCloseTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "twin emp too close", 1) {}
    bool IsActiveInEncounter() override;
};

// ---- Ouro ----

// Ouro is submerged (26063 visual, boss despawned/unselectable while dirt mounds 15712
// chase players): stay away from the mounds - they shockwave/quake the spot they reach
// (guide: 钻地后产生多个土堆追击玩家，躲开).
class OuroSubmergedTrigger : public AhnQirajEncounterTrigger
{
public:
    OuroSubmergedTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "ouro submerged", 2) {}
    bool IsActiveInEncounter() override;
};

// Ouro Scarabs (15718) are up after the boss re-emerges or during the 20% berserk:
// ranged burn them down (guide: 钻出后刷新小虫；狂暴后场内不断刷新小虫).
class OuroScarabsUpTrigger : public AhnQirajEncounterTrigger
{
public:
    OuroScarabsUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "ouro scarabs up", 2) {}
    bool IsActiveInEncounter() override;
};

// ---- C'Thun ----

// The Eye turns red (22518) then sweeps Dark Glare (26029) for 35s: everyone keeps moving
// out of the sweeping beam (guide: 眼睛绿变红的时候，全体跑位).
class CthunDarkGlareTrigger : public AhnQirajEncounterTrigger
{
public:
    CthunDarkGlareTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "cthun dark glare", 1) {}
    bool IsActiveInEncounter() override;
};

// Tentacles (small claw 15725 / small eye 15726) are up outside the stomach: ranged burn
// them on sight (guide: 远程职业优先击杀尖爪触须，沿途击杀眼球触须).
class CthunTentaclesUpTrigger : public AhnQirajEncounterTrigger
{
public:
    CthunTentaclesUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "cthun tentacles up", 2) {}
    bool IsActiveInEncounter() override;
};

// A giant tentacle (claw 15728 / eye 15334) is up: claw needs a tank before DPS, eye must
// be interrupted/killed fast (guide: 巨爪触须伤害极高，坦克没拉住别急着打).
class CthunGiantTentacleUpTrigger : public AhnQirajEncounterTrigger
{
public:
    CthunGiantTentacleUpTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "cthun giant tentacle up", 2) {}
    bool IsActiveInEncounter() override;
};

// This bot is inside the stomach (z < 0 / has Digestive Acid): attack the flesh tentacles
// - two dead tentacles weaken C'Thun (guide: 肚子里先上台子杀伤血肉触须).
class CthunInStomachTrigger : public AhnQirajEncounterTrigger
{
public:
    CthunInStomachTrigger(PlayerbotAI* ai) : AhnQirajEncounterTrigger(ai, "cthun in stomach", 2) {}
    bool IsActiveInEncounter() override;
};

#endif
